# in this file you will have informations about installed packages from the shinken cli command
