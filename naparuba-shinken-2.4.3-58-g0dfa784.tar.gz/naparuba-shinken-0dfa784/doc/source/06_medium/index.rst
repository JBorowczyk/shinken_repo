.. raw:: LaTeX

    \newpage

.. _medium/index:

Medium
======

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 2

   business-rules
   dmz-monitoring
   high-availability
   mix-windows-and-linux-polling
   notification-escalations
   notification-ways
   passive-checks
   snapshots
