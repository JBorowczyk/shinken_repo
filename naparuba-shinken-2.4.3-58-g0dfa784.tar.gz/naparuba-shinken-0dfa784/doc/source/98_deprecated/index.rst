.. raw:: LaTeX

    \newpage

.. _deprecated/index:

Deprecated
===========

The following content is deprecated in this Shinken version and may be completely removed soon.

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 2


   whatsnew

