.. _monitoring/monitoring-a-linux-via-local-agent:

==========================================
Monitoring Linux devices via a Local Agent 
==========================================


.. note::  **TODO** Documentation needs to be written

See:
  * :ref:`Chapter 9. Monitoring GNU/Linux &amp; Unix Machines <monitoring/monitoring-a-linux>`


NRPE 
=====

.. image:: /_static/images///official/images/nrpe.png
   :scale: 90 %


See:
  * Shinken Module to bypass check_nrpe tool: :ref:`NRPE Module <packages/setup-nrpe-booster-module>`


NSCA 
=====

.. image:: /_static/images///official/images/nsca.png
   :scale: 90 %


See:
  * Shinken Module to natively receive NSCA messages : :ref:` <nsca_daemon_module>`
