.. raw:: LaTeX

    \newpage

.. _thebasics/index:

The Basics
==========

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 2

   configure-shinken
   plugins
   macros
   macrolist
   hostchecks
   servicechecks
   activechecks
   passivechecks
   statetypes
   timeperiods
   networkreachability
   notifications
   active-module-checks
   dependencies-in-shinken
   update

