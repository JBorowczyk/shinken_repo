.. _advanced/clusters:

======================================
 Monitoring Service and Host Clusters 
======================================


Introduction 
=============

This "cluster" monitoring was managed by the check_cluster2 plugin in the Nagios times, now it's fully integer to the core, so you should read the new business rules that can be used for cluster monitoring :)
:ref:`Here <medium/business-rules>`.

