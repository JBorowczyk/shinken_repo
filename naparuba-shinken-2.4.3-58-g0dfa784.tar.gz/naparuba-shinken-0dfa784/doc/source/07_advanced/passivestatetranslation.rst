.. _advanced/passivestatetranslation:

================================
 Passive Host State Translation 
================================


Introduction 
=============

This Nagios option is no more useful in the Shinken architecture.

