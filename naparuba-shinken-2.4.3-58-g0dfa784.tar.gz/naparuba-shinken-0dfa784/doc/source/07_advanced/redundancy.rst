.. _advanced/redundancy:

===========================================
 Redundant and Failover Network Monitoring 
===========================================


Introduction 
=============

**This topic is managed in the distributed section because it's a part of the Shinken architecture.**

