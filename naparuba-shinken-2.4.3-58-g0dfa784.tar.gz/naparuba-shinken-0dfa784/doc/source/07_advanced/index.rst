.. raw:: LaTeX

    \newpage

.. _advanced/index:

Advanced Topics
===============

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 1

   extcommands
   eventhandlers
   volatileservices
   freshness
   distributed
   redundancy
   flapping
   escalations
   oncallrotation
   clusters
   dependencies
   stalking
   perfdata
   downtime
   adaptative
   dependencychecks
   cachedchecks
   passivestatetranslation
   checkscheduling
   objectinheritance
   objecttricks
   migratingfromnagios
   multi-layer-discovery
   multiple-urls
   rule-agregation
   scaling-shinken
   advanced-dependencies
   distributed-shinken
   distributed-with-realm
   businessimpact-modulations
   check-modulations
   macro-modulations
   result-modulations
   sms-with-android
   sms-with-gateway
   triggers
   unused-nagios-parameters
   discovery-with-shinken-advanced
   discovery-with-shinken
   internals-monitoring
