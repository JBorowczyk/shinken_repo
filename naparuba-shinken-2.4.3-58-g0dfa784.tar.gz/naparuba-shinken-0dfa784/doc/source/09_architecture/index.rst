.. raw:: LaTeX

    \newpage
	
.. _architecture/index:

Shinken Architecture
====================

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 2
   
   about-the-high-availability
   advanced-features
   how-dispatching-works
   problems-and-impacts
   the-shinken-architecture
