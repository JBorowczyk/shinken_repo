discovery Package
=================

:mod:`discovery` Package
------------------------

.. automodule:: shinken.discovery
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`discoverymanager` Module
------------------------------

.. automodule:: shinken.discovery.discoverymanager
    :members:
    :undoc-members:
    :show-inheritance:

