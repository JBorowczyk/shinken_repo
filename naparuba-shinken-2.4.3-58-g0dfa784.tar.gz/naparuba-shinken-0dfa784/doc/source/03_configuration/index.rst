.. raw:: LaTeX

    \newpage

.. _configuration/index:

Configuring Shinken
===================

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 2
    
   config
   configmain
   configobject
   objectdefinitions
   customobjectvars
   configmain-advanced
