.. raw:: LaTeX

    \newpage

.. _packages/index:

Shinken modules
===============

This part must be splitted and sent in all module repositories

.. raw:: LaTeX

    \newpage

.. toctree::
   :glob:
   :maxdepth: 2
      
   *
   */index
