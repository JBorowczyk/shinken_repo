.. _integration/thruk-screenshot:

================
Thruk interface 
================


Thruk is a web interface to get feedback about shinken status. You can also send command for asking shinken a new check, set a downtime on a host etc.  


.. image:: /_static/images/shinken_with_thruk.png
   :scale: 90 %

