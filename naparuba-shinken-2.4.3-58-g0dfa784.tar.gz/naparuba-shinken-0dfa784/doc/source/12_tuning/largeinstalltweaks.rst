.. _tuning/largeinstalltweaks:

================================
 Scaling a Shinken installation 
================================


Introduction 
=============

Shinken is designed to scale horizontally, but carefully planning your deployment will improve chances of success.


Scalability guide 
==================

Learn how to prepare by reading the main :ref:`scalability guide for large Shinken installations <advanced/scaling-shinken>`


