.. _tuning/mrtggraphs:
.. _tuning/nagiostats:

==================================================
Graphing Performance Info With MRTG and nagiostats
==================================================

.. todo: implement this page

Some basic info can be found on http://nagios.sourceforge.net/docs/3_0/mrtggraphs.html