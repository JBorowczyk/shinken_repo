.. _gettingstarted/upgrading-shinken:

===================
 Upgrading Shinken 
===================


Upgrading From Previous Shinken Releases 
=========================================

See the :ref:`update page for that <thebasics/update>`. Basically it's only about backuping and installing from a later git version (or package).


Upgrading From Nagios 3.x 
==========================

Just install Shinken and start the arbiter with your Nagios configuration. That's all.
