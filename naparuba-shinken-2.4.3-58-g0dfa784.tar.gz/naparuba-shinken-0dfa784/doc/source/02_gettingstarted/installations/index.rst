.. raw:: LaTeX

    \newpage

.. _gettingstarted/installations/index:

Installations
=============

.. raw:: LaTeX

    \newpage

.. toctree::


    shinken-installation
    shinken-env-setup
    shinken-first-steps
