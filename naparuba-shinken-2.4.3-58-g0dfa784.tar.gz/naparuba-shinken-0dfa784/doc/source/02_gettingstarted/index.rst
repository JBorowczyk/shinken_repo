.. raw:: LaTeX

    \newpage

.. _gettingstarted/index:

Getting Started
===============

.. raw:: LaTeX

    \newpage

.. toctree::
   :maxdepth: 2

   beginners
   installations/index
   upgrading-shinken

