.. _development/modules:

===================================
 Developing Shinken Daemon Modules 
===================================


How to develop daemon modules...

Coming shortly.
