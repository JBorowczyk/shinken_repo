/** JUST FOR MY PERSONAL DEV USE **/
drop database if exists nconf;
create database nconf;
use nconf;
source /home/frogx/sources/naparuba/shinken/install.d/config.nconf/nconf.sql;