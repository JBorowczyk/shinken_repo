<?php
/*
#
# User/Password file for simple authentication
# To disable a user, rows can be commented out with "#"
#
# :: is the delimiter of the fields
# Do NOT use :: (2 colons) in a data field (as name or password etc.)!
#
#username::password::authorization(user|admin)::[user's full name (optional)]::
admin::nconf::admin::Administrator::
#user::1234::user::Normal User::
#dummy::9999::user::User Dummy::
#foo::bar::user::foo bar::
#
# using encrypted passwords
#user2::{CRYPT}s7FkIgzTWZia2::user::User with a CRYPT password::
#
*/
?>
