Soit /^l'utilisation d'un navigateur$/ do
end

Soit /^le formulaire d'authentification$/ do
end

Soit /^l'écran vue personnelle$/ do
end

