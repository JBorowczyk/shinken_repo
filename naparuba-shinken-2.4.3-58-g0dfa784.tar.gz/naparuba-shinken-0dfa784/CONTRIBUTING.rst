Please have a look to the `development`_ guidline before sumitting a pull request, especially `this`_ part


.. _development: https://shinken.readthedocs.org/en/latest/15_development/index.html
.. _this: https://shinken.readthedocs.org/en/latest/15_development/hackingcode.html#development-rules